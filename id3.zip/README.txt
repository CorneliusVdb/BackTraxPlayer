=================================================================
README:

This is a VB project for manipulating ID3v1 and ID3v2 tags from
MP3 files.  It is a work in progress.

The code is fairly well commented.  If you make improvements to
the code, please share it with me and I'll do the same.

Regards,

Kevin Pohl
kevinpohl@threefifteen.net
=================================================================
